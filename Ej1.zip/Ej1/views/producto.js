$(document).ready(function() {
    function cargarProductos() {
        $.ajax({
            url: '../controllers/productos.controllers.php', // Ruta a tu archivo controlador de productos
            method: 'GET',
            success: function(data) {
                var html = '';
                $.each(data, function(index, producto) {
                    html += '<tr>' +
                            '<td>' + (index + 1) + '</td>' +
                            '<td>' + producto.nombre + '</td>' +
                            '<td>' + producto.precio + '</td>' +
                            '<td>' + producto.stock + '</td>' +
                            '<td><button class="btn btn-primary" onclick="editarProducto(' + producto.id + ')">Editar</button> ' +
                            '<button class="btn btn-danger" onclick="eliminarProducto(' + producto.id + ')">Eliminar</button></td>' +
                            '</tr>';
                });
                $('#cuerpoProductos').html(html);
            },
            error: function() {
                alert("Error cargando la lista de productos");
            }
        });
    }

    cargarProductos();

    window.eliminarProducto = function(id) {
        if (confirm("¿Estás seguro de que quieres eliminar este producto?")) {
            $.ajax({
                url: '../controllers/productos.controllers.php', // Ajusta esta URL
                method: 'DELETE',
                contentType: 'application/json',
                data: JSON.stringify({ ProductoId: id }),
                success: function(response) {
                    cargarProductos();
                    alert("Producto eliminado");
                },
                error: function() {
                    alert("Error al eliminar el producto");
                }
            });
        }
    };

    window.editarProducto = function(id) {
        // Lógica para editar producto
        // Por ejemplo, redireccionar a una página de edición o mostrar un modal
        window.location.href = '/ruta/a/editor/productos?id=' + id; // Ajusta según tu lógica de edición
    };
});
